<!-- Joelle Tsaku, u24984362 -->

<template>
  <NuxtLayout>
    <NuxtPage />
  </NuxtLayout>
</template>